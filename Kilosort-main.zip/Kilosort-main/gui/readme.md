## The all-new Kilosort GUI!

The GUI is intended as a launcher for Kilosort, to help you run it on your data without errors and to do some sanity checks that it is working properly. It does NOT include any functionality for manually curating/revising/editing the results of the algorithm, so it is not a replacement for Phy or for other careful manual inspection.

For more information on how to set up a Kilosort2 run using the GUI, go to the [GUI wiki page](https://github.com/MouseLand/Kilosort2/wiki/1.-The-GUI). 

Built by Nick Steinmetz. 
