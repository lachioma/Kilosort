function x = sq(x)


x = squeeze(x);