function x = gather_try(x)
try
    x = gather(x);
catch
end
end